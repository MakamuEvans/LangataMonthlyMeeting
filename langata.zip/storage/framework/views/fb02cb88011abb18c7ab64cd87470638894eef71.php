<?php $__env->startSection('content'); ?>
    <div class="page-head" data-bg-image="<?php echo e(url('images/page-head-1.jpg')); ?>">
        <div class="container">
            <h2 class="page-title">Leaders/Monthly Meeting</h2>
        </div>
    </div>

    <div class="fullwidth-block">
        <div class="container">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="news">
                            <image class="news-image" src="<?php echo e(url('images/news-thumb-1.jpg')); ?>"></image>
                            <h3 class="news-title"><a href="#">First Name, Last Name</a></h3>
                            <h3 class="news-title"><a href="#">Position</a></h3>
                            <small class="date"><i class="fa fa-calendar"></i>Contact details</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="news">
                            <image class="news-image" src="<?php echo e(url('images/news-thumb-1.jpg')); ?>"></image>
                            <h3 class="news-title"><a href="#">First Name, Last Name</a></h3>
                            <h3 class="news-title"><a href="#">Position</a></h3>
                            <small class="date"><i class="fa fa-calendar"></i>Contact details</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="news">
                            <image class="news-image" src="<?php echo e(url('images/news-thumb-1.jpg')); ?>"></image>
                            <h3 class="news-title"><a href="#">First Name, Last Name</a></h3>
                            <h3 class="news-title"><a href="#">Position</a></h3>
                            <small class="date"><i class="fa fa-calendar"></i>Contact details</small>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="news">
                            <image class="news-image" src="<?php echo e(url('images/news-thumb-1.jpg')); ?>"></image>
                            <h3 class="news-title"><a href="#">First Name, Last Name</a></h3>
                            <h3 class="news-title"><a href="#">Position</a></h3>
                            <small class="date"><i class="fa fa-calendar"></i>Contact details</small>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>