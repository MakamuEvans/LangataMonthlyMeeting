<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/elm.css')); ?>">
    <style>
        .theme-l {
            color: #1F55AB !important;
        }
        a{
            color: #1F55AB !important;
        }
        item:hover a{
            border-bottom-color: #1F55AB !important;
        }
    </style>

</head>
<body>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Scripts -->
<script src="<?php echo e(url('js/jquery-1.11.1.min.js')); ?>"></script>
<script src="<?php echo e(url('js/plugins.js')); ?>"></script>
<script src="<?php echo e(url('js/app.js')); ?>"></script>
</body>
</html>
