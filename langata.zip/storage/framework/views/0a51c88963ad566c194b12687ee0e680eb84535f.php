<header class="site-header">
    <div class="container">
        <a href="#" class="branding">
            <img src="<?php echo e(url('images/langata.jpg')); ?>" style="width: 250px;height: auto" alt="" class="logo">
            <div class="row" style="margin: 0px;padding: 0px">
                <i class="form-control">Lang'ata monthly meeting of friends church, P.O. BOX 51654, 00200-Nairobi</i>
            </div>
        </a>

        <div class="main-navigation">
            <button class="menu-toggle"><i class="fa fa-bars"></i> Menu</button>
            <ul class="menu theme-l">
                <?php if(isset($home)): ?>
                    <li class="menu-item current-menu-item theme-l"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <?php else: ?>
                    <li class="menu-item theme-l"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <?php endif; ?>
                <?php if(isset($about_us)): ?>
                    <li class="menu-item current-menu-item"><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
                <?php else: ?>
                    <li class="menu-item"><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
                <?php endif; ?>
                <?php if(isset($ministries)): ?>
                        <li class="menu-item current-menu-item"><a href="<?php echo e(url('ministries')); ?>">Ministries</a></li>
                <?php else: ?>
                        <li class="menu-item"><a href="<?php echo e(url('ministries')); ?>">Ministries</a></li>
                <?php endif; ?>
                <?php if(isset($leaders)): ?>
                        <li class="menu-item current-menu-item"><a href="<?php echo e(url('leaders')); ?>">Leaders</a></li>
                <?php else: ?>
                        <li class="menu-item"><a href="<?php echo e(url('leaders')); ?>">Leaders</a></li>
                <?php endif; ?>
                <?php if(isset($sermons)): ?>
                        <li class="menu-item current-menu-item"><a href="<?php echo e(url('sermons')); ?>">Sermons</a></li>
                <?php else: ?>
                        <li class="menu-item"><a href="<?php echo e(url('sermons')); ?>">Sermons</a></li>
                <?php endif; ?>
                <?php if(isset($contact)): ?>
                        <li class="menu-item current-menu-item"><a href="<?php echo e(url('contact-us')); ?>">Contact</a></li>
                <?php else: ?>
                        <li class="menu-item"><a href="<?php echo e(url('contact-us')); ?>">Contact</a></li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="mobile-navigation"></div>
    </div>
</header> <!-- .site-header -->