<?php $__env->startSection('content'); ?>
    <div class="site-content">


        <div class="hero">
            <div class="slides">
                <li data-bg-image="images/church.jpg" style="opacity: 0.3">
                    <div class="container">
                        <div class="slide-content">
                        </div>
                    </div>
                </li>

                <li data-bg-image="images/slide-1.jpg">
                    <div class="container">
                        <div class="slide-content">
                            
                        </div>
                    </div>
                </li>
            </div>
        </div>

        <main class="main-content">
            <div class="fullwidth-block">
                <div class="container">
                    <div class="col-md-7" style="margin-right: 40px">
                        <b class="theme-l" style="font-size: 25px">Theme of the Year - 2017</b>

                        <div class="row">
                            <ul class="seremon-list large">
                                <li>
                                    <img src="images/thumb-1-120.png" alt="">
                                    <div class="seremon-detail">
                                        <h3 class="seremon-title"><a href="#">Enhancing Servant Leadership</a></h3>
                                        <div class="seremon-meta">
                                            <div class="pastor"><i class="fa fa-user"></i> John 9:4</div>
                                            <div class="date"><i class="fa fa-calendar"></i> Jan-Dec 2017</div>
                                        </div>
                                        <p>The bible quotation goes here</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4" style="margin: 10px">
                        <b class="theme-l" style="font-size: 20px">Theme of the Month - Sep</b>

                        <div class="row">
                            <ul class="seremon-list large">
                                <li>
                                    <img src="images/thumb-1-120.png" alt="">
                                    <div class="seremon-detail">
                                        <h3 class="seremon-title"><a href="#">Enhancing Servant Leadership</a></h3>
                                        <div class="seremon-meta">
                                            <div class="pastor"><i class="fa fa-user"></i> John 9:4</div>
                                            <div class="date"><i class="fa fa-calendar"></i> Jan-Dec 2017</div>
                                        </div>
                                        <p>The bible quotation goes here</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div> <!-- .container -->
            </div> <!-- section -->

            <div class="fullwidth-block">
                <div class="container">
                    <div class="row">
                        <b class="theme-l" style="font-size: 25px">Announcements / News</b>

                        <div class="row">
                            <div class="col-md-3 col-sm-6">
                                <div class="news">
                                    <image class="news-image" src="images/news-thumb-1.jpg"></image>
                                    <h3 class="news-title"><a href="#">Item 1</a></h3>
                                    <small class="date"><i class="fa fa-calendar"></i>24 mar 2017</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="news">
                                    <image class="news-image" src="images/news-thumb-2.jpg"></image>
                                    <h3 class="news-title"><a href="#">Item 2</a></h3>
                                    <small class="date"><i class="fa fa-calendar"></i>24 mar 2017</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="news">
                                    <image class="news-image" src="images/news-thumb-3.jpg"></image>
                                    <h3 class="news-title"><a href="#">Item 3</a></h3>
                                    <small class="date"><i class="fa fa-calendar"></i>24 mar 2017</small>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <div class="news">
                                    <image class="news-image" src="images/news-thumb-4.jpg"></image>
                                    <h3 class="news-title"><a href="#">Item 4</a></h3>
                                    <small class="date"><i class="fa fa-calendar"></i>24 mar 2017</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main> <!-- .main-content -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>