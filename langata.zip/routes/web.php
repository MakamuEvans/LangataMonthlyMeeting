<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $home= true;
    return view('index', compact('home'));
});
Route::get('/about-us', function () {
    $about_us = true;
    return view('aboutus', compact('about_us'));
});
Route::get('/leaders', function () {
    $leaders = true;
    return view('leaders', compact('leaders'));
});
Route::get('/programs/quakers-men', function () {
    $leaders = true;
    return view('programs.quaker', compact('leaders'));
});
Route::get('/programs/sunday-school', function () {
    $leaders = true;
    return view('programs.sunday', compact('leaders'));
});
Route::get('/programs/usfw', function () {
    $leaders = true;
    return view('programs.usfw', compact('leaders'));
});
Route::get('/programs/youth', function () {
    $leaders = true;
    return view('programs.youth', compact('leaders'));
});


Route::get('/local-meeting/langata', function () {
    $leaders = true;
    return view('local.langata', compact('leaders'));
});
Route::get('/local-meeting/ongata-rongai', function () {
    $leaders = true;
    return view('local.ongata', compact('leaders'));
});
Route::get('/local-meeting/nairobi-west', function () {
    $leaders = true;
    return view('local.nairobi', compact('leaders'));
});

Route::get('/leaders/nairobi-yearly-meeting', function () {
    $leaders = true;
    return view('top.yearly', compact('leaders'));
});
Route::get('/leaders/monthly-meeting', function () {
    $leaders = true;
    return view('top.monthly', compact('leaders'));
});

Route::get('/committee/mission-commission', function () {
    $leaders = true;
    return view('committee.mission', compact('leaders'));
});Route::get('/committee/personal', function () {
    $leaders = true;
    return view('committee.personal', compact('leaders'));
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
